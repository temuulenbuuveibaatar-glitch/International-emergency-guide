import { useState } from "react";
import { Link, useLocation } from "wouter";
import logoSmall from "../assets/logo-small.svg";
import { useLanguage } from "../context/LanguageContext";
import LanguageSelector from "./LanguageSelector";

export default function Navigation() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [location] = useLocation();
  const { t } = useLanguage();

  const isActive = (path: string) => {
    return location === path;
  };

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <header className="sticky top-0 z-50 bg-red-600 shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between py-3">
          <Link href="/" className="text-white font-bold text-xl flex items-center">
            <img src={logoSmall} alt="Medical Emergency Guide Logo" className="w-8 h-8 mr-2" />
            Emergency Guide
          </Link>
          <nav className="hidden md:block">
            <ul className="flex space-x-1">
              <li>
                <Link 
                  href="/" 
                  className={`text-white hover:bg-red-700 px-3 py-2 rounded-md text-sm font-medium block ${isActive('/') ? 'bg-red-700' : ''}`}
                >
                  {t.home}
                </Link>
              </li>
              <li>
                <Link 
                  href="/emergency" 
                  className={`text-white hover:bg-red-700 px-3 py-2 rounded-md text-sm font-medium block ${isActive('/emergency') ? 'bg-red-700' : ''}`}
                >
                  {t.emergencyProtocols}
                </Link>
              </li>
              <li>
                <Link 
                  href="/treatments" 
                  className={`text-white hover:bg-red-700 px-3 py-2 rounded-md text-sm font-medium block ${isActive('/treatments') ? 'bg-red-700' : ''}`}
                >
                  {t.treatmentGuidelines}
                </Link>
              </li>
              <li>
                <Link 
                  href="/medications" 
                  className={`text-white hover:bg-red-700 px-3 py-2 rounded-md text-sm font-medium block ${isActive('/medications') ? 'bg-red-700' : ''}`}
                >
                  {t.medicationDatabase}
                </Link>
              </li>
              <li>
                <Link 
                  href="/symptom-checker" 
                  className={`text-white hover:bg-red-700 px-3 py-2 rounded-md text-sm font-medium block ${isActive('/symptom-checker') ? 'bg-red-700' : ''}`}
                >
                  {t.symptomChecker}
                </Link>
              </li>
              <li>
                <Link 
                  href="/nearby-hospitals" 
                  className={`text-white hover:bg-red-700 px-3 py-2 rounded-md text-sm font-medium block ${isActive('/nearby-hospitals') ? 'bg-red-700' : ''}`}
                >
                  {t.nearbyHospitals}
                </Link>
              </li>
            </ul>
          </nav>
          <div className="flex items-center space-x-2">
            <LanguageSelector />
            <button 
              className="md:hidden text-white"
              onClick={toggleMobileMenu}
              aria-label="Toggle menu"
            >
              <svg className="w-6 h-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>
        <div className={`md:hidden pb-3 ${mobileMenuOpen ? 'block' : 'hidden'}`}>
          <div className="mb-2 pl-3">
            <LanguageSelector />
          </div>
          <Link 
            href="/" 
            className={`text-white hover:bg-red-700 px-3 py-2 rounded-md text-sm font-medium block ${isActive('/') ? 'bg-red-700' : ''}`}
            onClick={() => setMobileMenuOpen(false)}
          >
            {t.home}
          </Link>
          <Link 
            href="/emergency" 
            className={`text-white hover:bg-red-700 px-3 py-2 rounded-md text-sm font-medium block ${isActive('/emergency') ? 'bg-red-700' : ''}`}
            onClick={() => setMobileMenuOpen(false)}
          >
            {t.emergencyProtocols}
          </Link>
          <Link 
            href="/treatments" 
            className={`text-white hover:bg-red-700 px-3 py-2 rounded-md text-sm font-medium block ${isActive('/treatments') ? 'bg-red-700' : ''}`}
            onClick={() => setMobileMenuOpen(false)}
          >
            {t.treatmentGuidelines}
          </Link>
          <Link 
            href="/medications" 
            className={`text-white hover:bg-red-700 px-3 py-2 rounded-md text-sm font-medium block ${isActive('/medications') ? 'bg-red-700' : ''}`}
            onClick={() => setMobileMenuOpen(false)}
          >
            {t.medicationDatabase}
          </Link>
          <Link 
            href="/symptom-checker" 
            className={`text-white hover:bg-red-700 px-3 py-2 rounded-md text-sm font-medium block ${isActive('/symptom-checker') ? 'bg-red-700' : ''}`}
            onClick={() => setMobileMenuOpen(false)}
          >
            {t.symptomChecker}
          </Link>
          <Link 
            href="/nearby-hospitals" 
            className={`text-white hover:bg-red-700 px-3 py-2 rounded-md text-sm font-medium block ${isActive('/nearby-hospitals') ? 'bg-red-700' : ''}`}
            onClick={() => setMobileMenuOpen(false)}
          >
            {t.nearbyHospitals}
          </Link>
        </div>
      </div>
    </header>
  );
}
