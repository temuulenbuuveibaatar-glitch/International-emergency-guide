import { ChevronDown } from "lucide-react";

interface Protocol {
  id: string;
  title: string;
  steps: {
    title: string;
    items: string[];
  };
  note?: string;
  svg?: string;
}

interface EmergencyAccordionProps {
  protocol: Protocol;
  isExpanded: boolean;
  onToggle: () => void;
}

export default function EmergencyAccordion({ protocol, isExpanded, onToggle }: EmergencyAccordionProps) {
  return (
    <div className="mb-4 bg-[#FFF8E6] border-l-4 border-yellow-400 rounded-md overflow-hidden">
      <button
        onClick={onToggle}
        className="w-full px-4 py-3 text-left font-medium bg-[#FFF8E6] hover:bg-[#FFEEBA] focus:outline-none flex justify-between items-center"
        aria-expanded={isExpanded}
      >
        <span>{protocol.title}</span>
        <ChevronDown 
          className={`w-5 h-5 transform transition-transform ${isExpanded ? 'rotate-180' : ''}`} 
        />
      </button>
      
      <div 
        className={`transition-all duration-300 ease-in-out overflow-hidden ${isExpanded ? 'max-h-[1000px]' : 'max-h-0'}`}
        aria-hidden={!isExpanded}
      >
        <div className="px-4 py-3 bg-white">
          <h3 className="font-semibold mb-2">{protocol.steps.title}:</h3>
          {protocol.steps.items.length > 0 && (
            <ol className="list-decimal pl-5 mb-3">
              {protocol.steps.items.map((item, index) => (
                <li key={index}>{item}</li>
              ))}
            </ol>
          )}
          
          {protocol.note && (
            <p className="text-sm bg-[#E2E3E5] text-[#383D41] p-2 rounded">{protocol.note}</p>
          )}
          
          {protocol.svg && (
            <div className="mt-3 flex justify-center" dangerouslySetInnerHTML={{ __html: protocol.svg }} />
          )}
        </div>
      </div>
    </div>
  );
}
