import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";

const LanguageSelector: React.FC = () => {
  const { language, setLanguage, languageNames, supportedLanguages } = useLanguage();

  const handleLanguageChange = (value: string) => {
    setLanguage(value as 'en' | 'mn');
  };

  return (
    <div className="language-selector">
      <Select value={language} onValueChange={handleLanguageChange}>
        <SelectTrigger className="w-[130px]">
          <SelectValue placeholder={languageNames[language]} />
        </SelectTrigger>
        <SelectContent>
          {supportedLanguages.map((lang) => (
            <SelectItem key={lang} value={lang}>
              {languageNames[lang]}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
};

export default LanguageSelector;