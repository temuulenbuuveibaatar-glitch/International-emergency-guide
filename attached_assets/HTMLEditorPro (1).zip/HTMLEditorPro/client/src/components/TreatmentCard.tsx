import { CheckCircle2 } from "lucide-react";

interface Treatment {
  id: string;
  title: string;
  guidelines: string[];
}

interface TreatmentCardProps {
  treatment: Treatment;
}

export default function TreatmentCard({ treatment }: TreatmentCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-5 mb-5">
      <h3 className="text-xl font-semibold mb-3 text-gray-800">{treatment.title}</h3>
      <div className="space-y-2">
        {treatment.guidelines.map((guideline, index) => (
          <div key={index} className="flex items-start">
            <CheckCircle2 className="w-5 h-5 text-green-600 mt-0.5 mr-2 flex-shrink-0" />
            <p>{guideline}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
