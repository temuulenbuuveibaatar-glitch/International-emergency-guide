export default function Footer() {
  return (
    <footer className="bg-gray-800 text-white py-6">
      <div className="container mx-auto px-4">
        <div className="md:flex md:justify-between">
          <div className="mb-4 md:mb-0">
            <h2 className="text-lg font-bold mb-2">Medical Emergency & Treatment Guide</h2>
            <p className="text-sm text-gray-300">A comprehensive resource for emergency and medical information.</p>
          </div>
          <div className="mt-4 md:mt-0">
            <h3 className="text-sm font-bold mb-2 uppercase">Important Disclaimer</h3>
            <p className="text-sm text-gray-300">
              This guide is for informational purposes only. It is not a substitute for professional 
              medical advice, diagnosis, or treatment. Always seek the advice of your physician or 
              other qualified health provider.
            </p>
          </div>
        </div>
        <div className="mt-6 border-t border-gray-700 pt-4">
          <p className="text-sm text-gray-400 text-center">
            &copy; {new Date().getFullYear()} Medical Emergency & Treatment Guide. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
