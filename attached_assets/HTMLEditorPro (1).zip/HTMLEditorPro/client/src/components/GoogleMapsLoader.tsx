import React, { useState, useEffect, useCallback } from 'react';
import { 
  GoogleMap, 
  useJsApiLoader, 
  Marker, 
  InfoWindow,
  Libraries
} from '@react-google-maps/api';
import { Loader2 } from 'lucide-react';

// Define libraries outside component to avoid unnecessary rerenders
const libraries: Libraries = ['places'];

// Set the container style for the map
const containerStyle = {
  width: '100%',
  height: '500px'
};

interface Hospital {
  name: string;
  vicinity: string;
  geometry: {
    location: {
      lat: number;
      lng: number;
    };
  };
  place_id: string;
}

interface Location {
  lat: number;
  lng: number;
}

interface GoogleMapsLoaderProps {
  onHospitalsFound?: (hospitals: Hospital[]) => void;
  onUserLocationFound?: (location: Location) => void;
  onLocationError?: (error: string) => void;
  onCountryCodeFound?: (code: string) => void;
  searchRadius?: number;
  selectedHospital?: Hospital | null;
  onHospitalSelect?: (hospital: Hospital | null) => void;
  userLocation?: Location | null;
}

export default function GoogleMapsLoader({
  onHospitalsFound,
  onUserLocationFound,
  onLocationError,
  onCountryCodeFound,
  searchRadius = 5000,
  selectedHospital,
  onHospitalSelect,
  userLocation
}: GoogleMapsLoaderProps) {
  const [center, setCenter] = useState<Location>({ lat: 40.7128, lng: -74.0060 }); // Default to New York
  const [loading, setLoading] = useState<boolean>(false);
  const [mapLoaded, setMapLoaded] = useState<boolean>(false);
  
  // Get the Google Maps API key from environment variables
  const apiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '';
  
  // Load Google Maps API
  const { isLoaded } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: apiKey,
    libraries
  });

  // Reference to keep track of the Google Map instance
  const [map, setMap] = useState<google.maps.Map | null>(null);

  const onLoad = useCallback((map: google.maps.Map) => {
    setMap(map);
    setMapLoaded(true);
  }, []);

  const onUnmount = useCallback(() => {
    setMap(null);
    setMapLoaded(false);
  }, []);
  
  // Get user's current location
  const getUserLocation = useCallback(() => {
    if (!isLoaded) return;
    setLoading(true);
    
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const location = {
            lat: position.coords.latitude,
            lng: position.coords.longitude
          };
          
          setCenter(location);
          if (onUserLocationFound) {
            onUserLocationFound(location);
          }
          
          setLoading(false);
          
          // Try to determine country for emergency numbers
          if (onCountryCodeFound) {
            getCountryFromCoordinates(location);
          }
        },
        (error) => {
          console.error("Error getting user location:", error);
          if (onLocationError) {
            onLocationError("Unable to get your location. Please check your browser settings and try again.");
          }
          setLoading(false);
        },
        { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 }
      );
    } else {
      if (onLocationError) {
        onLocationError("Geolocation is not supported by your browser.");
      }
      setLoading(false);
    }
  }, [isLoaded, onUserLocationFound, onLocationError, onCountryCodeFound]);

  // Get country code from coordinates using Google Maps Geocoding API
  const getCountryFromCoordinates = useCallback((location: Location) => {
    if (!isLoaded) return;
    
    try {
      const geocoder = new window.google.maps.Geocoder();
      geocoder.geocode({ location: location }, (results, status) => {
        if (status === "OK" && results && results[0]) {
          for (const component of results[0].address_components) {
            if (component.types.includes("country")) {
              const code = component.short_name;
              if (onCountryCodeFound) {
                onCountryCodeFound(code);
              }
              break;
            }
          }
        }
      });
    } catch (error) {
      console.error("Error getting country:", error);
    }
  }, [isLoaded, onCountryCodeFound]);

  // Find nearby hospitals using Google Places API
  const findNearbyHospitals = useCallback((location: Location) => {
    if (!isLoaded || !location) return;
    
    setLoading(true);
    
    try {
      // Create a place service
      const service = new window.google.maps.places.PlacesService(
        document.createElement('div')
      );
      
      const request = {
        location: location,
        radius: searchRadius,
        type: 'hospital'
      };
      
      service.nearbySearch(request, (results, status) => {
        if (status === window.google.maps.places.PlacesServiceStatus.OK && results) {
          // Convert results to our Hospital type
          const foundHospitals = results.map(place => ({
            name: place.name || 'Unnamed Hospital',
            vicinity: place.vicinity || 'No address provided',
            geometry: {
              location: {
                lat: place.geometry?.location?.lat() || 0,
                lng: place.geometry?.location?.lng() || 0
              }
            },
            place_id: place.place_id || ''
          }));
          
          if (onHospitalsFound) {
            onHospitalsFound(foundHospitals);
          }
        } else {
          if (onLocationError) {
            onLocationError("No hospitals found nearby. Try increasing the search radius.");
          }
        }
        setLoading(false);
      });
    } catch (error) {
      console.error("Error finding hospitals:", error);
      if (onLocationError) {
        onLocationError("Error finding hospitals. Please try again later.");
      }
      setLoading(false);
    }
  }, [isLoaded, searchRadius, onHospitalsFound, onLocationError]);

  // Initialize by getting user location on component mount
  useEffect(() => {
    if (isLoaded) {
      getUserLocation();
    }
  }, [isLoaded, getUserLocation]);

  // Get hospitals when user location is available
  useEffect(() => {
    if (userLocation && isLoaded && mapLoaded) {
      findNearbyHospitals(userLocation);
    }
  }, [userLocation, isLoaded, mapLoaded, findNearbyHospitals]);

  // Update center when user location changes
  useEffect(() => {
    if (userLocation) {
      setCenter(userLocation);
    }
  }, [userLocation]);
  
  if (!isLoaded) {
    return (
      <div className="flex justify-center items-center h-96">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <GoogleMap
      mapContainerStyle={containerStyle}
      center={center}
      zoom={12}
      onLoad={onLoad}
      onUnmount={onUnmount}
    >
      {/* User's position marker */}
      {userLocation && (
        <Marker
          position={userLocation}
          icon={{
            url: 'https://maps.google.com/mapfiles/ms/icons/blue-dot.png',
            scaledSize: new window.google.maps.Size(40, 40)
          }}
          title="Your Location"
        />
      )}
      
      {/* Children can be hospital markers or other map elements */}
      {selectedHospital && (
        <InfoWindow
          position={selectedHospital.geometry.location}
          onCloseClick={() => onHospitalSelect && onHospitalSelect(null)}
        >
          <div>
            <h3 className="font-semibold">{selectedHospital.name}</h3>
            <p>{selectedHospital.vicinity}</p>
            <a
              href={`https://www.google.com/maps/dir/?api=1&destination=${selectedHospital.geometry.location.lat},${selectedHospital.geometry.location.lng}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-600 hover:underline mt-2 inline-block"
            >
              Get Directions
            </a>
          </div>
        </InfoWindow>
      )}
    </GoogleMap>
  );
}

// Helper function to calculate distance between two points
export function calculateDistance(point1: Location | null, point2: Location): string {
  if (!point1) return "N/A";
  
  const R = 6371; // Radius of the earth in km
  const dLat = deg2rad(point2.lat - point1.lat);
  const dLng = deg2rad(point2.lng - point1.lng);
  
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(deg2rad(point1.lat)) * Math.cos(deg2rad(point2.lat)) *
    Math.sin(dLng / 2) * Math.sin(dLng / 2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c; // Distance in km
  
  return distance.toFixed(1);
}

function deg2rad(deg: number): number {
  return deg * (Math.PI / 180);
}