import { useState } from "react";
import { medications } from "@/data/medications";

export default function MedicationDatabase() {
  const [searchTerm, setSearchTerm] = useState("");

  const filteredMedications = medications.filter((medication) =>
    Object.values(medication).some((value) =>
      value.toString().toLowerCase().includes(searchTerm.toLowerCase())
    )
  );

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="bg-gray-100 py-8 text-center mb-8 rounded-md">
        <h1 className="text-3xl font-bold mb-2">Medication Database</h1>
        <p className="text-gray-600">Expand your knowledge on emergency and chronic care medications</p>
      </div>

      <div className="mb-6">
        <div className="relative">
          <input
            type="text"
            placeholder="Search medications..."
            className="w-full p-3 pl-10 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-600"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <svg
            className="w-5 h-5 text-gray-400 absolute left-3 top-3.5"
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 20 20"
            fill="currentColor"
          >
            <path
              fillRule="evenodd"
              d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z"
              clipRule="evenodd"
            />
          </svg>
        </div>
      </div>

      <div className="overflow-x-auto bg-white rounded-lg shadow">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Medication
              </th>
              <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Indication
              </th>
              <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Dosage
              </th>
              <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Precautions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filteredMedications.map((medication) => (
              <tr key={medication.id} className="medication-row">
                <td className="px-4 py-3 whitespace-nowrap">
                  <div className="font-medium text-gray-900">{medication.name}</div>
                </td>
                <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">{medication.indication}</td>
                <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">{medication.dosage}</td>
                <td className="px-4 py-3 text-sm text-gray-500">{medication.precautions}</td>
              </tr>
            ))}
            {filteredMedications.length === 0 && (
              <tr>
                <td colSpan={4} className="px-4 py-3 text-center text-gray-500">
                  No medications found matching your search.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
