import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { getEmergencyNumbersByCountryCode, defaultEmergencyNumbers } from '../data/emergencyNumbers';
import { Loader2 } from 'lucide-react';
import GoogleMapsLoader, { calculateDistance } from '@/components/GoogleMapsLoader';
import { useLanguage } from '../context/LanguageContext';

interface Hospital {
  name: string;
  vicinity: string;
  geometry: {
    location: {
      lat: number;
      lng: number;
    };
  };
  place_id: string;
}

interface Location {
  lat: number;
  lng: number;
}

export default function NearbyHospitals() {
  const [hospitals, setHospitals] = useState<Hospital[]>([]);
  const [userLocation, setUserLocation] = useState<Location | null>(null);
  const [selectedHospital, setSelectedHospital] = useState<Hospital | null>(null);
  const [searchRadius, setSearchRadius] = useState<number>(5000); // 5km default radius
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [emergencyNumbers, setEmergencyNumbers] = useState(defaultEmergencyNumbers);
  const { t } = useLanguage();

  // Event handlers
  const handleUserLocationFound = (location: Location) => {
    setUserLocation(location);
    setLoading(false);
  };

  const handleHospitalsFound = (foundHospitals: Hospital[]) => {
    setHospitals(foundHospitals);
    setLoading(false);
  };

  const handleLocationError = (errorMessage: string) => {
    setError(errorMessage);
    setLoading(false);
  };

  const handleCountryCodeFound = (code: string) => {
    // Set emergency numbers based on country code
    const numbers = getEmergencyNumbersByCountryCode(code);
    if (numbers) {
      setEmergencyNumbers(numbers);
    } else {
      setEmergencyNumbers(defaultEmergencyNumbers);
    }
  };

  const handleRefreshButtonClick = () => {
    setLoading(true);
    // The GoogleMapsLoader component will automatically refresh the hospitals
    // when the userLocation and searchRadius changes
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-6">{t.nearbyHospitalsTitle}</h1>
      
      {/* Emergency Numbers Section */}
      <Card className="mb-6">
        <CardHeader className="bg-red-100 dark:bg-red-900">
          <CardTitle className="text-red-600 dark:text-red-300">{t.emergencyNumbers} - {emergencyNumbers.country}</CardTitle>
          <CardDescription>Call these numbers in case of emergency</CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
            <div>
              <div className="font-semibold">{t.police}</div>
              <div className="text-xl">{emergencyNumbers.police}</div>
            </div>
            <div>
              <div className="font-semibold">{t.ambulance}</div>
              <div className="text-xl">{emergencyNumbers.ambulance}</div>
            </div>
            <div>
              <div className="font-semibold">{t.fire}</div>
              <div className="text-xl">{emergencyNumbers.fire}</div>
            </div>
            <div>
              <div className="font-semibold">{t.general}</div>
              <div className="text-xl">{emergencyNumbers.general}</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Map Controls */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <Button 
          onClick={() => setLoading(true)} 
          className="flex items-center" 
          disabled={loading}
        >
          {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          {t.findingLocation}
        </Button>
        
        <div className="flex-1 flex items-center gap-2">
          <span>Search radius:</span>
          <Input
            type="number"
            min="1000"
            max="50000"
            value={searchRadius}
            onChange={(e) => setSearchRadius(Number(e.target.value))}
            className="w-32"
          />
          <span>meters</span>
        </div>
        
        <Button 
          onClick={handleRefreshButtonClick} 
          disabled={!userLocation || loading}
          variant="outline"
        >
          {t.searchingHospitals}
        </Button>
      </div>
      
      {/* Error Messages */}
      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      
      {/* Map Display */}
      <Card className="mb-6 overflow-hidden">
        <GoogleMapsLoader
          onHospitalsFound={handleHospitalsFound}
          onUserLocationFound={handleUserLocationFound}
          onLocationError={handleLocationError}
          onCountryCodeFound={handleCountryCodeFound}
          searchRadius={searchRadius}
          selectedHospital={selectedHospital}
          onHospitalSelect={setSelectedHospital}
          userLocation={userLocation}
        />
      </Card>
      
      {/* Hospital List */}
      <h2 className="text-2xl font-semibold mb-4">{t.nearbyHospitalsTitle}</h2>
      {loading ? (
        <div className="flex justify-center py-8">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {hospitals.length > 0 ? (
            hospitals.map((hospital) => (
              <Card 
                key={hospital.place_id}
                className="hover:shadow-lg transition-shadow cursor-pointer"
                onClick={() => setSelectedHospital(hospital)}
              >
                <CardHeader>
                  <CardTitle className="text-lg">{hospital.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 dark:text-gray-300">{hospital.vicinity}</p>
                  <Separator className="my-3" />
                  <div className="flex justify-between items-center">
                    <a
                      href={`https://www.google.com/maps/dir/?api=1&destination=${hospital.geometry.location.lat},${hospital.geometry.location.lng}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline inline-block"
                      onClick={(e) => e.stopPropagation()}
                    >
                      {t.getDirections}
                    </a>
                    <span className="text-sm text-gray-500">
                      {calculateDistance(userLocation, hospital.geometry.location)} km {t.distanceAway}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="col-span-full text-center py-8 text-gray-500">
              {error ? error : t.locationError}
            </div>
          )}
        </div>
      )}
    </div>
  );
}