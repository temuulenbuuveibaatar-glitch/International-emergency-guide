import { Link } from "wouter";
import logo from "../assets/logo.svg";

export default function Home() {
  return (
    <>
      <section className="bg-gray-100 py-12 md:py-20">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <div className="mx-auto w-40 h-40 mb-4">
              <img src={logo} alt="Medical Emergency Guide Logo" className="w-full h-full" />
            </div>
            <h1 className="text-3xl md:text-4xl font-bold mb-3">Medical Emergency & Treatment Guide</h1>
            <p className="text-lg text-gray-600 mb-6">Life-saving information at your fingertips</p>
            <div className="max-w-md mx-auto">
              <div className="bg-white p-4 rounded-lg shadow-md">
                <h2 className="text-lg font-semibold text-red-600 mb-2">Emergency?</h2>
                <p className="text-gray-700 mb-3 text-sm">If someone is in immediate danger, call emergency services:</p>
                <a href="tel:911" className="bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-lg inline-block transition">
                  Call 911 Now
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
          <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
            <h2 className="text-xl font-bold mb-3 text-red-600">Emergency Protocols</h2>
            <p className="text-gray-700 mb-4">Immediate steps and guidelines during critical moments.</p>
            <Link to="/emergency" className="text-red-600 font-medium hover:underline">View Protocols →</Link>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
            <h2 className="text-xl font-bold mb-3 text-red-600">Treatment Guidelines</h2>
            <p className="text-gray-700 mb-4">Comprehensive care strategies for various conditions.</p>
            <Link to="/treatments" className="text-red-600 font-medium hover:underline">View Guidelines →</Link>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
            <h2 className="text-xl font-bold mb-3 text-red-600">Medication Database</h2>
            <p className="text-gray-700 mb-4">Search for information on emergency and chronic care medications.</p>
            <Link to="/medications" className="text-red-600 font-medium hover:underline">Search Medications →</Link>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
            <h2 className="text-xl font-bold mb-3 text-red-600">Symptom Checker</h2>
            <p className="text-gray-700 mb-4">Identify potential conditions based on your symptoms.</p>
            <Link to="/symptom-checker" className="text-red-600 font-medium hover:underline">Check Symptoms →</Link>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
            <h2 className="text-xl font-bold mb-3 text-red-600">Nearby Hospitals</h2>
            <p className="text-gray-700 mb-4">Find emergency medical facilities near your current location.</p>
            <Link to="/nearby-hospitals" className="text-red-600 font-medium hover:underline">Find Hospitals →</Link>
          </div>
        </div>

        <div className="mt-12 bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded-md">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-yellow-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2h-1V9a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-sm text-yellow-700">
                <strong>Disclaimer:</strong> This guide is for informational purposes only. It is not a substitute for professional medical advice, diagnosis, or treatment. Always seek the advice of your physician or other qualified health provider.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
