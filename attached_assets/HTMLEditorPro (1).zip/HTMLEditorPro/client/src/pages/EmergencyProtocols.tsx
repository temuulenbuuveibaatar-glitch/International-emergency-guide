import { useState } from "react";
import EmergencyAccordion from "@/components/EmergencyAccordion";
import { emergencyProtocols } from "@/data/emergencyProtocols";

export default function EmergencyProtocols() {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const toggleAccordion = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="bg-gray-100 py-8 text-center mb-8 rounded-md">
        <h1 className="text-3xl font-bold mb-2">Emergency Protocols</h1>
        <p className="text-gray-600">Immediate steps and extra guidelines during critical moments</p>
      </div>

      <div className="mb-4 text-gray-700">
        <p>Click on each emergency for detailed protocols.</p>
      </div>

      {emergencyProtocols.map((protocol) => (
        <EmergencyAccordion
          key={protocol.id}
          protocol={protocol}
          isExpanded={expandedId === protocol.id}
          onToggle={() => toggleAccordion(protocol.id)}
        />
      ))}
    </div>
  );
}
