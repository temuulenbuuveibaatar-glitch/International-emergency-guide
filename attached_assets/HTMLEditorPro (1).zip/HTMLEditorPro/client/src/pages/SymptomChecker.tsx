import { useState } from "react";
import { symptoms } from "@/data/symptoms";

export default function SymptomChecker() {
  const [selectedSymptom, setSelectedSymptom] = useState("");
  const [conditions, setConditions] = useState<string[]>([]);

  const handleSymptomChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const symptomId = e.target.value;
    setSelectedSymptom(symptomId);

    if (!symptomId) {
      setConditions([]);
      return;
    }

    const symptom = symptoms.find((s) => s.id === symptomId);
    if (symptom) {
      setConditions(symptom.conditions);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="bg-gray-100 py-8 text-center mb-8 rounded-md">
        <h1 className="text-3xl font-bold mb-2">Symptom Checker</h1>
        <p className="text-gray-600">Identify potential conditions and receive guidance based on your symptoms</p>
      </div>

      <p className="mb-6 text-gray-700">
        This tool is for informational purposes only and does not replace professional medical advice.
      </p>

      <div className="bg-white rounded-lg shadow-md p-5 mb-8">
        <div className="mb-4">
          <label htmlFor="symptomSelect" className="block text-sm font-medium text-gray-700 mb-1">
            Select your primary symptom:
          </label>
          <select
            id="symptomSelect"
            className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-600"
            value={selectedSymptom}
            onChange={handleSymptomChange}
          >
            <option value="">Select a symptom</option>
            {symptoms.map((symptom) => (
              <option key={symptom.id} value={symptom.id}>
                {symptom.name}
              </option>
            ))}
          </select>
        </div>

        {selectedSymptom && (
          <div className="mt-5 p-4 bg-gray-50 rounded-lg">
            <h3 className="text-lg font-semibold mb-2">Possible Conditions:</h3>
            <ul className="list-disc pl-5 space-y-1">
              {conditions.map((condition, index) => (
                <li key={index}>{condition}</li>
              ))}
            </ul>
            <div className="mt-4 bg-blue-50 border border-blue-200 text-blue-800 p-3 rounded">
              <div className="flex">
                <svg
                  className="w-5 h-5 text-blue-600 mr-2 flex-shrink-0"
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 20 20"
                  fill="currentColor"
                >
                  <path
                    fillRule="evenodd"
                    d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2h-1V9a1 1 0 00-1-1z"
                    clipRule="evenodd"
                  />
                </svg>
                <p className="text-sm">
                  This tool provides general information only. Always consult a healthcare professional for medical advice.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="bg-green-50 border border-green-200 p-4 rounded-lg">
        <h3 className="text-lg font-semibold text-green-800 mb-2">When to Seek Immediate Medical Attention</h3>
        <ul className="list-disc pl-5 text-green-700 space-y-1">
          <li>Difficulty breathing or shortness of breath</li>
          <li>Chest or upper abdominal pain or pressure</li>
          <li>Fainting, sudden dizziness, weakness</li>
          <li>Changes in vision or difficulty speaking</li>
          <li>Confusion or changes in mental status</li>
          <li>Any sudden or severe pain</li>
          <li>Uncontrolled bleeding</li>
        </ul>
      </div>
    </div>
  );
}
