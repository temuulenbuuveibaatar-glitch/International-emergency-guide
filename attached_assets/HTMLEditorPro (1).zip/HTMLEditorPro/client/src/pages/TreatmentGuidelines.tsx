import TreatmentCard from "@/components/TreatmentCard";
import { treatmentGuidelines } from "@/data/treatmentGuidelines";

export default function TreatmentGuidelines() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="bg-gray-100 py-8 text-center mb-8 rounded-md">
        <h1 className="text-3xl font-bold mb-2">Treatment Guidelines</h1>
        <p className="text-gray-600">Comprehensive care strategies for various conditions</p>
      </div>

      <p className="mb-6 text-gray-700">
        These guidelines are for reference only and should be implemented under proper medical supervision.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {treatmentGuidelines.map((treatment) => (
          <TreatmentCard key={treatment.id} treatment={treatment} />
        ))}
      </div>
    </div>
  );
}
