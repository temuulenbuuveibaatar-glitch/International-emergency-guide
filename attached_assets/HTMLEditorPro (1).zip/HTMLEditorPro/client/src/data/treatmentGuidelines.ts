export const treatmentGuidelines = [
  {
    id: "diabetes",
    title: "Diabetes Management",
    guidelines: [
      "Type 1: Insulin therapy required",
      "Type 2: Metformin + lifestyle changes",
      "Target HbA1c: <7% for most patients"
    ]
  },
  {
    id: "hypertension",
    title: "Hypertension Control",
    guidelines: [
      "First-line medications: ACE inhibitors, ARBs",
      "BP target: <140/90 mmHg for general population",
      "DASH diet recommended"
    ]
  },
  {
    id: "asthma",
    title: "Asthma Management",
    guidelines: [
      "Short-acting beta agonists (SABA) for acute relief",
      "Inhaled corticosteroids for long-term control",
      "Avoid known triggers and allergens"
    ]
  },
  {
    id: "post_operative",
    title: "Post-Operative Care",
    guidelines: [
      "Pain management with prescribed analgesics",
      "Wound care and infection prevention",
      "Gradual mobilization and physical therapy"
    ]
  },
  {
    id: "copd",
    title: "COPD Management",
    guidelines: [
      "Smoking cessation is essential",
      "Bronchodilators for symptom relief",
      "Pulmonary rehabilitation recommended",
      "Oxygen therapy for severe cases"
    ]
  },
  {
    id: "depression",
    title: "Depression Treatment",
    guidelines: [
      "Combination of medication and psychotherapy",
      "Regular follow-up to monitor response",
      "Exercise and social engagement",
      "Monitor for suicidal ideation"
    ]
  }
];
