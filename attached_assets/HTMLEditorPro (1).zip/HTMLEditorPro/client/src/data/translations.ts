// Define all supported languages
export type SupportedLanguage = 'en' | 'mn';

// Define the language names
export const languageNames: Record<SupportedLanguage, string> = {
  en: 'English',
  mn: 'Монгол'
};

// Define the translation structure
export interface TranslationStrings {
  // Navigation
  home: string;
  emergencyProtocols: string;
  treatmentGuidelines: string;
  medicationDatabase: string;
  symptomChecker: string;
  nearbyHospitals: string;
  
  // Home page
  welcomeTitle: string;
  welcomeSubtitle: string;
  quickAction: string;
  findHospital: string;
  checkSymptoms: string;
  viewTreatments: string;
  emergencyProtocolsDesc: string;
  
  // Emergency Protocols
  emergencyProtocolsTitle: string;
  searchProtocols: string;
  steps: string;
  note: string;
  
  // Treatment Guidelines
  treatmentGuidelinesTitle: string;
  searchTreatments: string;
  guidelines: string;
  
  // Medication Database
  medicationDatabaseTitle: string;
  searchMedications: string;
  usedFor: string;
  commonDosage: string;
  sideEffects: string;
  warnings: string;
  
  // Symptom Checker
  symptomCheckerTitle: string;
  selectSymptoms: string;
  possibleConditions: string;
  whatToDoNext: string;
  seekMedicalHelp: string;
  
  // Nearby Hospitals
  nearbyHospitalsTitle: string;
  findingLocation: string;
  searchingHospitals: string;
  distanceAway: string;
  getDirections: string;
  locationError: string;
  
  // Emergency Numbers
  emergencyNumbers: string;
  police: string;
  ambulance: string;
  fire: string;
  general: string;
  
  // Common
  loading: string;
  search: string;
  noResults: string;
  error: string;
  back: string;
  showMore: string;
  showLess: string;
}

// English translations
export const en: TranslationStrings = {
  // Navigation
  home: 'Home',
  emergencyProtocols: 'Emergency Protocols',
  treatmentGuidelines: 'Treatment Guidelines',
  medicationDatabase: 'Medication Database',
  symptomChecker: 'Symptom Checker',
  nearbyHospitals: 'Nearby Hospitals',
  
  // Home page
  welcomeTitle: 'Medical Emergency & Treatment Guide',
  welcomeSubtitle: 'Your comprehensive resource for medical emergencies and treatments',
  quickAction: 'Quick Actions',
  findHospital: 'Find a Hospital',
  checkSymptoms: 'Check Symptoms',
  viewTreatments: 'View Treatments',
  emergencyProtocolsDesc: 'Step-by-step emergency protocols',
  
  // Emergency Protocols
  emergencyProtocolsTitle: 'Emergency Protocols',
  searchProtocols: 'Search protocols',
  steps: 'Steps',
  note: 'Note',
  
  // Treatment Guidelines
  treatmentGuidelinesTitle: 'Treatment Guidelines',
  searchTreatments: 'Search treatments',
  guidelines: 'Guidelines',
  
  // Medication Database
  medicationDatabaseTitle: 'Medication Database',
  searchMedications: 'Search medications',
  usedFor: 'Used For',
  commonDosage: 'Common Dosage',
  sideEffects: 'Side Effects',
  warnings: 'Warnings',
  
  // Symptom Checker
  symptomCheckerTitle: 'Symptom Checker',
  selectSymptoms: 'Select your symptoms',
  possibleConditions: 'Possible conditions',
  whatToDoNext: 'What to do next',
  seekMedicalHelp: 'Seek medical help if symptoms persist or worsen',
  
  // Nearby Hospitals
  nearbyHospitalsTitle: 'Nearby Hospitals',
  findingLocation: 'Finding your location...',
  searchingHospitals: 'Searching for nearby hospitals...',
  distanceAway: 'away',
  getDirections: 'Get directions',
  locationError: 'Could not determine your location. Please enable location services.',
  
  // Emergency Numbers
  emergencyNumbers: 'Emergency Numbers',
  police: 'Police',
  ambulance: 'Ambulance',
  fire: 'Fire',
  general: 'General Emergency',
  
  // Common
  loading: 'Loading...',
  search: 'Search',
  noResults: 'No results found',
  error: 'An error occurred',
  back: 'Back',
  showMore: 'Show more',
  showLess: 'Show less'
};

// Mongolian translations
export const mn: TranslationStrings = {
  // Navigation
  home: 'Нүүр хуудас',
  emergencyProtocols: 'Яаралтай тусламжийн протоколууд',
  treatmentGuidelines: 'Эмчилгээний зааварчилгаа',
  medicationDatabase: 'Эмийн мэдээллийн сан',
  symptomChecker: 'Шинж тэмдгийн шалгагч',
  nearbyHospitals: 'Ойролцоох эмнэлэгүүд',
  
  // Home page
  welcomeTitle: 'Яаралтай эмнэлгийн тусламж & Эмчилгээний гарын авлага',
  welcomeSubtitle: 'Яаралтай эмнэлгийн тусламж, эмчилгээний талаар бүрэн мэдээлэл',
  quickAction: 'Түргэн үйлдлүүд',
  findHospital: 'Эмнэлэг хайх',
  checkSymptoms: 'Шинж тэмдгээ шалгах',
  viewTreatments: 'Эмчилгээний зааварчилгаа үзэх',
  emergencyProtocolsDesc: 'Алхам алхмаар яаралтай тусламжийн протоколууд',
  
  // Emergency Protocols
  emergencyProtocolsTitle: 'Яаралтай тусламжийн протоколууд',
  searchProtocols: 'Протоколууд хайх',
  steps: 'Алхамууд',
  note: 'Тэмдэглэл',
  
  // Treatment Guidelines
  treatmentGuidelinesTitle: 'Эмчилгээний зааварчилгаа',
  searchTreatments: 'Эмчилгээ хайх',
  guidelines: 'Зааварчилгаа',
  
  // Medication Database
  medicationDatabaseTitle: 'Эмийн мэдээллийн сан',
  searchMedications: 'Эм хайх',
  usedFor: 'Хэрэглэх зориулалт',
  commonDosage: 'Ердийн тун',
  sideEffects: 'Гаж нөлөө',
  warnings: 'Анхааруулга',
  
  // Symptom Checker
  symptomCheckerTitle: 'Шинж тэмдгийн шалгагч',
  selectSymptoms: 'Шинж тэмдгээ сонгоно уу',
  possibleConditions: 'Болзошгүй нөхцөл байдал',
  whatToDoNext: 'Дараа нь юу хийх вэ',
  seekMedicalHelp: 'Шинж тэмдэг үргэлжилсэн эсвэл дордсон тохиолдолд эмнэлгийн тусламж эрэлхийлнэ үү',
  
  // Nearby Hospitals
  nearbyHospitalsTitle: 'Ойролцоох эмнэлэгүүд',
  findingLocation: 'Таны байршлыг тодорхойлж байна...',
  searchingHospitals: 'Ойролцоох эмнэлэгүүдийг хайж байна...',
  distanceAway: 'зайтай',
  getDirections: 'Чиглүүлэг авах',
  locationError: 'Таны байршлыг тодорхойлж чадсангүй. Байршлын үйлчилгээг идэвхжүүлнэ үү.',
  
  // Emergency Numbers
  emergencyNumbers: 'Яаралтай тусламжийн дугаарууд',
  police: 'Цагдаа',
  ambulance: 'Түргэн тусламж',
  fire: 'Гал түймэр',
  general: 'Ерөнхий яаралтай тусламж',
  
  // Common
  loading: 'Ачаалж байна...',
  search: 'Хайх',
  noResults: 'Үр дүн олдсонгүй',
  error: 'Алдаа гарлаа',
  back: 'Буцах',
  showMore: 'Дэлгэрэнгүй',
  showLess: 'Хураангуй'
};

// Dictionary of all translations
export const translations: Record<SupportedLanguage, TranslationStrings> = {
  en,
  mn
};