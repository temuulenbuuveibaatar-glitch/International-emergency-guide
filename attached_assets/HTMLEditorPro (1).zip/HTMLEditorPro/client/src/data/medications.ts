export const medications = [
  {
    id: "1",
    name: "Epinephrine",
    indication: "Anaphylaxis",
    dosage: "0.3-0.5 mg IM",
    precautions: "Monitor for tachycardia"
  },
  {
    id: "2",
    name: "Albuterol",
    indication: "Asthma attacks",
    dosage: "2-4 puffs every 20 min",
    precautions: "Contraindicated in soy allergies"
  },
  {
    id: "3",
    name: "Naloxone",
    indication: "Opioid overdose",
    dosage: "0.4 mg IM/IV",
    precautions: "Repeat every 2-3 min if needed"
  },
  {
    id: "4",
    name: "Aspirin",
    indication: "Heart attack",
    dosage: "325 mg (chewed)",
    precautions: "Avoid in children with viral infections"
  },
  {
    id: "5",
    name: "Metformin",
    indication: "Type 2 Diabetes",
    dosage: "500-1000 mg BID",
    precautions: "Monitor renal function"
  },
  {
    id: "6",
    name: "Lisinopril",
    indication: "Hypertension",
    dosage: "10-40 mg daily",
    precautions: "Monitor potassium levels"
  },
  {
    id: "7",
    name: "Ibuprofen",
    indication: "Pain/Inflammation",
    dosage: "200-400 mg every 4-6 hours",
    precautions: "Avoid in patients with peptic ulcers"
  },
  {
    id: "8",
    name: "Amoxicillin",
    indication: "Bacterial infections",
    dosage: "250-500 mg TID",
    precautions: "Discontinue if rash develops"
  },
  {
    id: "9",
    name: "Atorvastatin",
    indication: "Hypercholesterolemia",
    dosage: "10-80 mg daily",
    precautions: "Monitor liver function"
  },
  {
    id: "10",
    name: "Levothyroxine",
    indication: "Hypothyroidism",
    dosage: "25-200 mcg daily",
    precautions: "Take on empty stomach"
  },
  {
    id: "11",
    name: "Lorazepam",
    indication: "Status epilepticus",
    dosage: "2-4 mg IV",
    precautions: "Monitor for respiratory depression"
  },
  {
    id: "12",
    name: "Furosemide",
    indication: "Pulmonary edema",
    dosage: "40-80 mg IV",
    precautions: "Monitor electrolytes and renal function"
  },
  {
    id: "13",
    name: "Nitroglycerin",
    indication: "Angina",
    dosage: "0.4 mg sublingual",
    precautions: "Avoid in hypotension and head injury"
  },
  {
    id: "14",
    name: "Prednisone",
    indication: "Severe allergic reactions",
    dosage: "40-60 mg daily",
    precautions: "Taper dose when discontinuing"
  },
  {
    id: "15",
    name: "Insulin Glargine",
    indication: "Diabetes mellitus",
    dosage: "10-40 units SC daily",
    precautions: "Monitor for hypoglycemia"
  },
  {
    id: "16",
    name: "Dexamethasone",
    indication: "Cerebral edema",
    dosage: "4-10 mg IV q6h",
    precautions: "Monitor blood glucose"
  },
  {
    id: "17",
    name: "Morphine Sulfate",
    indication: "Severe pain",
    dosage: "2-10 mg IV/IM q4h",
    precautions: "Monitor respiratory status"
  },
  {
    id: "18",
    name: "Clopidogrel",
    indication: "ACS/Post-stent",
    dosage: "75 mg daily",
    precautions: "Increased bleeding risk"
  },
  {
    id: "19",
    name: "Ondansetron",
    indication: "Nausea/Vomiting",
    dosage: "4-8 mg IV/PO q8h",
    precautions: "QT prolongation"
  },
  {
    id: "20",
    name: "Ceftriaxone",
    indication: "Bacterial meningitis",
    dosage: "2 g IV q12h",
    precautions: "Cross-allergy with penicillins"
  }
];
