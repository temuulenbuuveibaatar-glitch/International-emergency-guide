export const emergencyProtocols = [
  {
    id: "cardiac_arrest",
    title: "Cardiac Arrest",
    steps: {
      title: "Immediate Steps",
      items: [
        "Call emergency services immediately",
        "Begin CPR: 100-120 chest compressions per minute",
        "Use AED if available"
      ]
    },
    note: "Survival rates drop 7-10% per minute without CPR",
    svg: `<svg width="200" height="150" viewBox="0 0 200 150" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M100 20C55.8172 20 20 55.8172 20 100C20 144.183 55.8172 180 100 180C144.183 180 180 144.183 180 100C180 55.8172 144.183 20 100 20Z" fill="#FFE2E6"/>
      <path d="M100 20V60L120 80L100 100L80 120L100 140L120 160H140" stroke="#DC3545" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>
      <path d="M100 20V60L80 80L100 100L120 120L100 140L80 160H60" stroke="#DC3545" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>`
  },
  {
    id: "stroke",
    title: "Stroke Recognition",
    steps: {
      title: "FAST Assessment",
      items: [
        "Face drooping",
        "Arm weakness",
        "Speech difficulty",
        "Time to call emergency"
      ]
    },
    note: "Ischemic strokes account for 87% of all strokes",
    svg: `<svg width="200" height="150" viewBox="0 0 200 150" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M100 30C55.8172 30 20 65.8172 20 110C20 154.183 55.8172 190 100 190C144.183 190 180 154.183 180 110C180 65.8172 144.183 30 100 30Z" fill="#E6F7FF"/>
      <path d="M70 80C70 74.4772 74.4772 70 80 70H120C125.523 70 130 74.4772 130 80V120C130 125.523 125.523 130 120 130H80C74.4772 130 70 125.523 70 120V80Z" fill="#FFE2E6"/>
      <path d="M85 90C85 87.2386 87.2386 85 90 85H110C112.761 85 115 87.2386 115 90V110C115 112.761 112.761 115 110 115H90C87.2386 115 85 112.761 85 110V90Z" fill="#DC3545"/>
      <path d="M150 60L140 80L160 80L150 100" stroke="#2C3E50" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
      <path d="M40 110H60M80 110H100M120 110H140M160 110H180" stroke="#2C3E50" stroke-width="4" stroke-linecap="round" stroke-dasharray="2 8"/>
    </svg>`
  },
  {
    id: "allergic_reaction",
    title: "Severe Allergic Reaction",
    steps: {
      title: "Action Plan",
      items: [
        "Administer epinephrine auto-injector immediately",
        "Call emergency services",
        "Monitor breathing and circulation"
      ]
    },
    note: "Antihistamines alone are insufficient for anaphylaxis",
    svg: `<svg width="200" height="150" viewBox="0 0 200 150" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="70" y="40" width="60" height="120" rx="5" fill="#FFE2E6"/>
      <rect x="80" y="50" width="40" height="100" rx="3" fill="#DC3545"/>
      <path d="M90 70L110 70" stroke="white" stroke-width="4" stroke-linecap="round"/>
      <path d="M90 90L110 90" stroke="white" stroke-width="4" stroke-linecap="round"/>
      <path d="M100 60L100 100" stroke="white" stroke-width="4" stroke-linecap="round"/>
      <path d="M85 130L115 130L100 110L85 130Z" fill="white"/>
    </svg>`
  },
  {
    id: "severe_trauma",
    title: "Severe Trauma / Bleeding",
    steps: {
      title: "Steps to Manage Severe Trauma",
      items: [
        "Ensure your own safety and then assist the victim",
        "Apply direct pressure to bleeding wounds",
        "If available, use a tourniquet for uncontrolled bleeding on limbs",
        "Keep the victim warm and monitor for signs of shock",
        "Call emergency services immediately"
      ]
    },
    note: "Quick action to control bleeding can be lifesaving."
  },
  {
    id: "overdose",
    title: "Overdose Management",
    steps: {
      title: "Overdose Response",
      items: [
        "Call emergency services immediately",
        "Administer Naloxone if opioid overdose is suspected",
        "Provide supportive care while waiting for help",
        "If unconscious, lay the person in the recovery position"
      ]
    },
    note: "Recognize signs like pinpoint pupils and respiratory depression."
  },
  {
    id: "heatstroke",
    title: "Heatstroke",
    steps: {
      title: "Steps to Cool Down",
      items: [
        "Move victim to a cooler environment.",
        "Remove excess clothing and fan skin while spraying cool water.",
        "Apply ice packs to armpits, groin, and neck.",
        "Monitor temperature—aim to lower to below 39°C (102°F).",
        "Call emergency services immediately."
      ]
    },
    note: "Untreated heatstroke can cause organ failure within minutes."
  },
  {
    id: "hypoglycemia",
    title: "Hypoglycemia (Low Blood Sugar)",
    steps: {
      title: "Immediate Actions",
      items: [
        "Check blood glucose if a meter is available.",
        "If conscious and able to swallow: give 15–20 g fast‑acting carbohydrate (e.g., glucose tablets, juice).",
        "Recheck in 15 minutes; repeat if still low.",
        "If unconscious: place in recovery position and call emergency services."
      ]
    },
    note: "Severe hypoglycemia can lead to seizures or coma if not treated."
  },
  {
    id: "choking",
    title: "Choking",
    steps: {
      title: "Heimlich Maneuver / Back Blows",
      items: [
        "If person can't speak or cough, stand behind and deliver 5 abdominal thrusts.",
        "If unsuccessful, give 5 back blows between the shoulder blades.",
        "Alternate until the object is expelled or the person becomes unresponsive.",
        "If unresponsive, begin CPR and call emergency services."
      ]
    },
    note: "Time to airway obstruction brain injury is about 4–6 minutes."
  },
  {
    id: "seizure",
    title: "Seizure",
    steps: {
      title: "Seizure First Aid",
      items: [
        "Protect head with a soft object; clear surrounding hazards.",
        "Do not restrain movements or place anything in the mouth.",
        "Once convulsing stops, place in recovery position.",
        "Check breathing; call emergency services if seizure >5 minutes or repeats."
      ]
    },
    note: "Prolonged seizures (status epilepticus) can cause permanent brain damage."
  }
];
