export interface EmergencyNumber {
  country: string;
  code: string;
  police: string;
  ambulance: string;
  fire: string;
  general: string;
}

export const emergencyNumbers: EmergencyNumber[] = [
  {
    country: "Mongolia",
    code: "MN",
    police: "102",
    ambulance: "103",
    fire: "101",
    general: "105"
  },
  {
    country: "United States",
    code: "US",
    police: "911",
    ambulance: "911",
    fire: "911",
    general: "911"
  },
  {
    country: "United Kingdom",
    code: "GB",
    police: "999",
    ambulance: "999",
    fire: "999",
    general: "999"
  },
  {
    country: "Australia",
    code: "AU",
    police: "000",
    ambulance: "000",
    fire: "000",
    general: "000"
  },
  {
    country: "Canada",
    code: "CA",
    police: "911",
    ambulance: "911",
    fire: "911",
    general: "911"
  },
  {
    country: "European Union",
    code: "EU",
    police: "112",
    ambulance: "112",
    fire: "112",
    general: "112"
  },
  {
    country: "India",
    code: "IN",
    police: "100",
    ambulance: "108",
    fire: "101",
    general: "112"
  },
  {
    country: "Japan",
    code: "JP",
    police: "110",
    ambulance: "119",
    fire: "119",
    general: "110"
  },
  {
    country: "China",
    code: "CN",
    police: "110",
    ambulance: "120",
    fire: "119",
    general: "110"
  },
  {
    country: "Brazil",
    code: "BR",
    police: "190",
    ambulance: "192",
    fire: "193",
    general: "190"
  },
  {
    country: "Mexico",
    code: "MX",
    police: "911",
    ambulance: "911",
    fire: "911",
    general: "911"
  },
  {
    country: "South Africa",
    code: "ZA",
    police: "10111",
    ambulance: "10177",
    fire: "10177",
    general: "112"
  },
  {
    country: "Russia",
    code: "RU",
    police: "102",
    ambulance: "103",
    fire: "101",
    general: "112"
  },
  {
    country: "New Zealand",
    code: "NZ",
    police: "111",
    ambulance: "111",
    fire: "111",
    general: "111"
  },
  {
    country: "Singapore",
    code: "SG",
    police: "999",
    ambulance: "995",
    fire: "995",
    general: "999"
  },
  {
    country: "South Korea",
    code: "KR",
    police: "112",
    ambulance: "119",
    fire: "119",
    general: "112"
  }
];

// Function to find the emergency numbers based on country code
export function getEmergencyNumbersByCountryCode(code: string): EmergencyNumber | undefined {
  return emergencyNumbers.find(item => item.code === code.toUpperCase());
}

// Default emergency numbers if country-specific ones cannot be determined
export const defaultEmergencyNumbers: EmergencyNumber = {
  country: "International",
  code: "INTL",
  police: "Check local numbers",
  ambulance: "Check local numbers",
  fire: "Check local numbers",
  general: "112 (in many countries)"
};