export const symptoms = [
  {
    id: "chest_pain",
    name: "Chest Pain",
    conditions: ["Heart attack", "Angina", "GERD", "Muscle strain"]
  },
  {
    id: "shortness_breath",
    name: "Shortness of Breath",
    conditions: ["Asthma", "Pulmonary embolism", "COPD", "Anxiety"]
  },
  {
    id: "headache",
    name: "Headache",
    conditions: ["Migraine", "Tension headache", "Hypertension", "Meningitis"]
  },
  {
    id: "abdominal_pain",
    name: "Abdominal Pain",
    conditions: ["Appendicitis", "Gallstones", "Gastritis", "Kidney stones"]
  },
  {
    id: "dizziness",
    name: "Dizziness",
    conditions: ["Dehydration", "Hypotension", "Inner ear infection", "Anemia"]
  },
  {
    id: "fatigue",
    name: "Fatigue",
    conditions: ["Sleep apnea", "Hypothyroidism", "Chronic fatigue syndrome", "Depression"]
  },
  {
    id: "fever",
    name: "Fever",
    conditions: ["Infection", "Influenza", "COVID-19", "Bacterial sepsis"]
  },
  {
    id: "rash",
    name: "Skin Rash",
    conditions: ["Allergic reaction", "Eczema", "Psoriasis", "Fungal infection"]
  },
  {
    id: "joint_pain",
    name: "Joint Pain",
    conditions: ["Arthritis", "Rheumatoid arthritis", "Gout", "Lupus"]
  },
  {
    id: "cough",
    name: "Cough",
    conditions: ["Common cold", "Bronchitis", "Pneumonia", "COVID-19"]
  }
];
