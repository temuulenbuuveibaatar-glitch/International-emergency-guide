import { Switch, Route, Router } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import EmergencyProtocols from "@/pages/EmergencyProtocols";
import TreatmentGuidelines from "@/pages/TreatmentGuidelines";
import MedicationDatabase from "@/pages/MedicationDatabase";
import SymptomChecker from "@/pages/SymptomChecker";
import NearbyHospitals from "@/pages/NearbyHospitals";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { LanguageProvider } from "./context/LanguageContext";

function AppRouter() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navigation />
      <main className="flex-grow">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/emergency" component={EmergencyProtocols} />
          <Route path="/treatments" component={TreatmentGuidelines} />
          <Route path="/medications" component={MedicationDatabase} />
          <Route path="/symptom-checker" component={SymptomChecker} />
          <Route path="/nearby-hospitals" component={NearbyHospitals} />
          <Route component={NotFound} />
        </Switch>
      </main>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <LanguageProvider>
        <TooltipProvider>
          <Toaster />
          <Router>
            <AppRouter />
          </Router>
        </TooltipProvider>
      </LanguageProvider>
    </QueryClientProvider>
  );
}

export default App;
