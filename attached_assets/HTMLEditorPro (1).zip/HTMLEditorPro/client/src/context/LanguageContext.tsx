import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { SupportedLanguage, translations, TranslationStrings, languageNames } from '../data/translations';

// Define the context shape
interface LanguageContextType {
  language: SupportedLanguage;
  setLanguage: (language: SupportedLanguage) => void;
  t: TranslationStrings;
  languageNames: Record<SupportedLanguage, string>;
  supportedLanguages: SupportedLanguage[];
}

// Create a context with a default value
const LanguageContext = createContext<LanguageContextType>({
  language: 'en',
  setLanguage: () => {},
  t: translations.en,
  languageNames: languageNames,
  supportedLanguages: ['en', 'mn']
});

// Create a provider component to wrap our app
interface LanguageProviderProps {
  children: ReactNode;
}

export const LanguageProvider = ({ children }: LanguageProviderProps) => {
  // Try to get the language from localStorage or use 'en' as default
  const getInitialLanguage = (): SupportedLanguage => {
    const savedLanguage = localStorage.getItem('language') as SupportedLanguage;
    if (savedLanguage && ['en', 'mn'].includes(savedLanguage)) {
      return savedLanguage;
    }
    return 'en';
  };

  const [language, setLanguageState] = useState<SupportedLanguage>(getInitialLanguage);
  const [t, setTranslations] = useState<TranslationStrings>(translations[language]);
  const supportedLanguages: SupportedLanguage[] = ['en', 'mn'];

  // Update translations when language changes
  useEffect(() => {
    setTranslations(translations[language]);
    localStorage.setItem('language', language);
    // Optionally update document language for accessibility
    document.documentElement.lang = language;
  }, [language]);

  // Setting language function
  const setLanguage = (newLanguage: SupportedLanguage) => {
    setLanguageState(newLanguage);
  };

  const value = {
    language,
    setLanguage,
    t,
    languageNames,
    supportedLanguages
  };

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
};

// Custom hook to use the language context
export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};